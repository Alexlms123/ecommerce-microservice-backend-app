
INSERT INTO payments
(order_id, is_payed, payment_status) VALUES
(1, false, 'IN_PROGRESS'),
(2, false, 'IN_PROGRESS'),
(3, false, 'IN_PROGRESS'),
(4, false, 'IN_PROGRESS');

